export const profile = [{ value: 403, text: "Please login to access this" }];

export const notfound = [
  {
    value: 404,
    text: "Page not found",
  },
];
